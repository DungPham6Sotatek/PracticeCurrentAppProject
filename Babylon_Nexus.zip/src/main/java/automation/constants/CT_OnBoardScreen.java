package automation.constants;

public class CT_OnBoardScreen {
	public static final String SIGNUP_BTN = "//android.widget.Button[@content-desc=\"Sign up\"]";
	
}
