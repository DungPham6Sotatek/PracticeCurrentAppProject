package automation.testsuite;

import static org.testng.Assert.assertTrue;

import java.net.MalformedURLException;
import java.net.URL;
import java.time.Duration;
import java.util.Iterator;

import org.openqa.selenium.By;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.HttpCommandExecutor;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.*;

import automation.common.CommonBase;
import automation.constants.CT_OnBoardScreen;
import automation.constants.CT_SignUpScreen;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.nativekey.AndroidKey;
import io.appium.java_client.android.nativekey.PressesKey;
import io.appium.java_client.pagefactory.AppiumElementLocatorFactory;

public class TestSignUp extends CommonBase{
	private AndroidDriver driver;
	private String name = "Jimmy";
	private String nameEmail = "dung.pham6+";
	private int number = 2000;
	private String domain = "@sotatek.com";
	private String email;
	@BeforeMethod
	public void init() {
		driver = openApp();
		number++;
		email =  nameEmail + number +domain;
		
		System.out.println(name);
		System.out.println(email);
	}
	
	@Test
	public void signUp_1() {
		System.out.println(driver.getSettings());
		clickToElement(By.xpath(CT_OnBoardScreen.SIGNUP_BTN));
		clickToElement(By.xpath(CT_SignUpScreen.FULLNAME_INPUT));
		
		sendKey(By.xpath(CT_SignUpScreen.FULLNAME_INPUT), name);
		
		closeKeyBoard();
		clickToElement(By.xpath(CT_SignUpScreen.CONTINUE_BTN));
		System.out.println(driver.getSessionId());
		
		clickToElement(By.xpath(CT_SignUpScreen.EMAIL_INPUT));
		sendKey(By.xpath(CT_SignUpScreen.EMAIL_INPUT), email);
		closeKeyBoard();
		
		clickToElement(By.xpath(CT_SignUpScreen.CONTINUE_BTN));
		clickToElement(By.xpath(CT_SignUpScreen.ELECTRICIAN_RBTN));
		clickToElement(By.xpath(CT_SignUpScreen.SIGNUP_BTN));
		assertTrue(isElementDisplay(By.xpath(CT_SignUpScreen.SUCCESSFULLY_CREATE_ACCCOUNT)));
	}
	@Test
	public void signUp_2() {
		System.out.println(driver.getSettings());
		clickToElement(By.xpath(CT_OnBoardScreen.SIGNUP_BTN));
		clickToElement(By.xpath(CT_SignUpScreen.FULLNAME_INPUT));
		
		sendKey(By.xpath(CT_SignUpScreen.FULLNAME_INPUT), name);
		
		closeKeyBoard();
		clickToElement(By.xpath(CT_SignUpScreen.CONTINUE_BTN));
		System.out.println(driver.getSessionId());
		
		clickToElement(By.xpath(CT_SignUpScreen.EMAIL_INPUT));
		sendKey(By.xpath(CT_SignUpScreen.EMAIL_INPUT), "email");
		closeKeyBoard();
		clickToElement(By.xpath(CT_SignUpScreen.CONTINUE_BTN));
		clickToElement(By.xpath(CT_SignUpScreen.ELECTRICIAN_RBTN));
		clickToElement(By.xpath(CT_SignUpScreen.SIGNUP_BTN));
		assertTrue(isElementDisplay(By.xpath(CT_SignUpScreen.SUCCESSFULLY_CREATE_ACCCOUNT)));
		number++;
		
	}
	@AfterMethod(alwaysRun = true)
	public void tearDown() {
		number++;
		 try {
		        if (driver != null) {
		            
		            if (driver.getSessionId() != null) {
		                driver.quit();  
		            }
		        }
		    } catch (Exception e) {
		        System.out.println("Error while closing the app: " + e.getMessage());
		    }
		
		   
	}
	
}
